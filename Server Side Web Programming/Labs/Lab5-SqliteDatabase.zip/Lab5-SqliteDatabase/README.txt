This lab can run both a console and GUI! You are given the option to choose which to run at the beginning of the application.

Lab 5 introduces us to packages and connecting to a database while also implementing a generic class that accepts different kinds of classes. 


This project uses the following packages from NuGet.org:
- Microsoft.Data.Sqlite