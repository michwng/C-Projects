﻿/**       
 * -------------------------------------------------------------------
 * 	   File name: Program.cs
 * 	Project name: Deserialization
 * -------------------------------------------------------------------
 *  Author’s name and email:    Michael Ng, ngmw01@etsu.edu			
 *              Tutorial By:    Rick Anderson, https://twitter.com/RickAndMSFT
 *            Creation Date:	04/05/2022	
 *            Last Modified:    04/07/2022
 * -------------------------------------------------------------------
 */

using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;

namespace MvcMovie.Controllers
{

    //localhost:5001/HelloWorld maps to the HelloWorld Controller class.
    public class HelloWorldController : Controller
    {
        // 
        // GET: /HelloWorld/
        //localhost:5001/HelloWorld/Index causes the
        //Index method of the HelloWorldController class to run.
        //Index is called on default on the URL "localhost:5001/HelloWorld/".
        /*public string Index()
        {
            return "This is my default action...";
        }*/

        public IActionResult Index()
        {
            return View();
        }

        // 
        // GET: /HelloWorld/Welcome/ 
        // Requires using System.Text.Encodings.Web;
        //public string Welcome(string name, int ID = 1)
        //{
        //    return HtmlEncoder.Default.Encode($"Hello {name}, ID: {ID}");
        //}


        public IActionResult Welcome(string name, int numTimes = 1)
        {
            ViewData["Message"] = "Hello " + name;
            ViewData["NumTimes"] = numTimes;

            return View();
        }
    }
}